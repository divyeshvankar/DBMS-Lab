-- task7
DELETE FROM grade18 ;